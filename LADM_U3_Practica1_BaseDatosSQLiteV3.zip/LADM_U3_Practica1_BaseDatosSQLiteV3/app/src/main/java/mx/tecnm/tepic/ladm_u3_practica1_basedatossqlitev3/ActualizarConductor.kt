package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_actualizar_conductor.*

class ActualizarConductor : AppCompatActivity() {
    var id = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actualizar_conductor)

        var extra = intent.extras
        id = extra!!.getString("idActualizar")!!

        //RECUPERAR LA DATA
        val conductor = Conductor(this).consulta(id)
        NombreConductor.setText(conductor.nombre)
        DomicilioConductor.setText(conductor.domicilio)
        LicenciaConductor.setText(conductor.NoLicencia)
        VencimientoLicenciaConductor.setText(conductor.vencer)

        actualizar.setOnClickListener {
            val ConductorActualizar = Conductor(this)
            ConductorActualizar.nombre = NombreConductor.text.toString()
            ConductorActualizar.domicilio = DomicilioConductor.text.toString()
            ConductorActualizar.NoLicencia = LicenciaConductor.text.toString()
            ConductorActualizar.vencer = VencimientoLicenciaConductor.text.toString()

            val resultado = ConductorActualizar.actualizar(id)
            if(resultado){
                Toast.makeText(this,"EXITO SE ACTUALIZO", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"ERROR NO SE LOGRO ACTUALIZAR", Toast.LENGTH_LONG).show()
            }
        }
        regresar.setOnClickListener {
            finish()
        }
    }
}