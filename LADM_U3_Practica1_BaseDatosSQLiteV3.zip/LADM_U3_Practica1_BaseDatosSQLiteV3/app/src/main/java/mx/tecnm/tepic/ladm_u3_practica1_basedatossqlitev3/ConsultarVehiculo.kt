package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_consulta_vehiculo.*
import kotlinx.android.synthetic.main.activity_consultar_conductor.*
import kotlinx.android.synthetic.main.activity_consultar_conductor.Buscar
import kotlinx.android.synthetic.main.activity_consultar_conductor.Regresar
import kotlinx.android.synthetic.main.activity_consultar_conductor.exportar
import kotlinx.android.synthetic.main.activity_consultar_conductor.opcionJuego
import java.io.IOException
import java.io.OutputStreamWriter

class ConsultarVehiculo : AppCompatActivity() {
    var idVehiculo= ArrayList<Int>()
    var exportarArchivo = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consulta_vehiculo)
        //listaCaptura()

        Buscar.setOnClickListener {

            var operacion = opcionJuego.selectedItemPosition
            when (operacion) {
                0 -> {
                    listaCaptura()
                }
                1 -> {

                }
                2 -> {

                }
            }//when
        }//Buscar

        Regresar.setOnClickListener {
            finish()
        }//regresar

        exportar.setOnClickListener {

        }//exportar
    }//onCreate

    private fun listaCaptura(){
        val arregloV = Vehiculo(this).consulta()
        exportarArchivo = arregloV
        listaVehiculos.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arregloV)
        idVehiculo.clear()
        idVehiculo = Vehiculo(this).obtenerIDs()
        activarEvento(listaVehiculos)

    }//listaCaptura

    private fun activarEvento(listaVehiculo: ListView){
        listaVehiculo.setOnItemClickListener { adapterView, view, indiceSeleccionado, l ->
            val idSeleccionado = idVehiculo[indiceSeleccionado]

            AlertDialog.Builder(this)
                .setNegativeButton("Modificar"){d,i->
                    AlertDialog.Builder(this)
                        .setTitle("ATENCION")
                        .setMessage("Que desea Realizar?")
                        .setPositiveButton("Actualizar"){d,i-> actualizar(idSeleccionado)}
                        .setNegativeButton("Eliminar"){d,i->eliminar(idSeleccionado)}
                        .setNeutralButton("Cancelar"){d,i-> d.cancel()}
                        .show()
                }
                .setNeutralButton("Cancelar"){d,i-> d.cancel()}
                .show()
        }
    }//activarEvento

    private fun actualizar(idSeleccionado: Int){
        val intento = Intent(this, ActualizarConductor::class.java)
        intento.putExtra("idActualizar",idSeleccionado.toString())
        startActivity(intento)
        AlertDialog.Builder(this).setMessage("DESEAS ACTUALIZAR LISTA?")
            .setPositiveButton("SI "){d,i-> listaCaptura()}
            .setNegativeButton("NO "){d,i-> d.cancel()}
            .show()
    }//actualizar

    private fun eliminar(idSeleccionado:Int){
        AlertDialog.Builder(this)
            .setTitle("IMPORTANTE")
            .setMessage("Seguro que deseas eliminar ID ${idSeleccionado}")
            .setPositiveButton("Si"){d,i->
                val resultado = Conductor(this).eliminar(idSeleccionado)
                if(resultado){
                    Toast.makeText(this,"Se elemino con exito", Toast.LENGTH_LONG).show()
                    listaCaptura()
                }else{
                    Toast.makeText(this,"Error no se logro eliminar", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("No"){d,i->
                d.cancel()
            }
            .show()
    }//eliminar

    private fun encontrarID(arregloConductor: ArrayList<String>) {
        exportarArchivo = arregloConductor
        val id = ArrayList<Int>()
        if (!(arregloConductor[0] == "No hay Conductores")) {
            for(i in arregloConductor){
                var aux = i.split(":")
                id.add(aux[1].toInt())
            }
            //idConductor.clear()
           // idConductor = id
            activarEvento(listaConductores)
        }
    }//encontrarID

    private fun exportarCSV(){
        try {
            var textoAGuardar = ""
            val archivo = OutputStreamWriter(openFileOutput("conductor" + ".txt", MODE_PRIVATE))
            Toast.makeText(this, "${archivo}", Toast.LENGTH_LONG).show()
            for(i in exportarArchivo) {
                var aux = i.split("\n")
                textoAGuardar = textoAGuardar+aux[0]+"," + aux[1]+","+aux[2]+","+aux[3]+","+aux[4]+"\n"
            }
            archivo.write(textoAGuardar) //hace el guardado de datos  en archivo
            archivo.flush()// forza a guardar  en este momento
            archivo.close() //se cierra para evitar alteraciones
            Toast.makeText(this, "Se guardo con exito", Toast.LENGTH_LONG)
                .show()
            //generartextView(textoTitulo,textocontenido)
        } catch (io: IOException) {
            AlertDialog.Builder(this)
                .setTitle("ATENCION!M ERROR")
                .setMessage(io.message)
                .setPositiveButton("ACEPTAR") { dialog, exception ->
                    dialog.dismiss()
                }
                .show()
        }
        /*for(i in exportarArchivo){
            var aux = i.split("\n")
            Toast.makeText(this,"${aux[0]} ${aux[1]} ${aux[2]} ${aux[3]} ${aux[4]}", Toast.LENGTH_LONG).show()
        }//for*/
    }//exportarCSV
}
