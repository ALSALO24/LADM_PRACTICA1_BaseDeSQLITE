package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BaseDatos(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context,name,factory,version){
    override fun onCreate(p: SQLiteDatabase) {
        //se ejecuta cuando se instala la app en el cel y corre por 1vez
        //en kotlin puedes hacer el crud de 2 maneras diferentes
        // 1. tradicional con instrucciones sql.(insert int,update, delete from, selec* from
        // 2. la poo que maneja metodos que ejecutan instrucciones ql
        p.execSQL("CREATE TABLE Conductor(IDCONDUCTOR INTEGER PRIMARY KEY AUTOINCREMENT,NOMBRE VARCHAR(200),DOMICILIO VARCHAR(200), NOLICENCIA VARCHAR(200), VENCER DATE )")
        p.execSQL("CREATE TABLE Vehiculo(IDVEHICULO INTEGER PRIMARY KEY AUTOINCREMENT,PLACA VARCHAR(200),MARCA VARCHAR(200), MODELO VARCHAR(200), YEARR INTEGER, IDCONDUCTOR INTEGER, FOREIGN KEY(IDCONDUCTOR) REFERENCES Conductor (IDCONDUCTOR) )")
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        //se ejecuta cuando hay un cambio de version
    }
}