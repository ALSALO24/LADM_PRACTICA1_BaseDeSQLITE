package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_actualizar_conductor.*
import kotlinx.android.synthetic.main.activity_actualizar_conductor.actualizar
import kotlinx.android.synthetic.main.activity_actualizar_conductor.regresar
import kotlinx.android.synthetic.main.activity_actualizar_vehiculo.*
import kotlinx.android.synthetic.main.activity_insertar_v.*

class actualizar_vehiculo : AppCompatActivity() {
    var id = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actualizar_vehiculo)
        var extra = intent.extras
        id = extra!!.getString("idActualizar")!!

        //RECUPERAR LA DATA
        val vehiculo = Vehiculo(this).consulta(id)
        NomPlaca.setText(vehiculo.placa)
        Marca.setText(vehiculo.marca)
        ModeloV.setText(vehiculo.modelo)
        YearV.setText(vehiculo.fecha)
        idcon.setText(vehiculo.idconductor)

        actualizar.setOnClickListener {
            val VehiculoActualizar = Vehiculo(this)
            VehiculoActualizar.placa = NomPlaca.text.toString()
            VehiculoActualizar.marca = ModeloV.text.toString()
            VehiculoActualizar.modelo = Marca.text.toString()
            VehiculoActualizar.fecha = YearV.text.toString()
            VehiculoActualizar.idconductor = idcon.text.toString()

            val resultado = VehiculoActualizar.actualizar(id)
            if(resultado){
                Toast.makeText(this,"EXITO SE ACTUALIZO", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"ERROR NO SE LOGRO ACTUALIZAR", Toast.LENGTH_LONG).show()
            }
        }
        regresar.setOnClickListener {
            finish()
        }
    }
}