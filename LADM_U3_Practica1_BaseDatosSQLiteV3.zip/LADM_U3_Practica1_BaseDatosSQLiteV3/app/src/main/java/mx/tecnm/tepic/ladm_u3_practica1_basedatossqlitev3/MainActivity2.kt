package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main2.*
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        botonInsertConductor.setOnClickListener {
            val InsertarConductor = Intent(applicationContext, Insertar::class.java).apply {}
            startActivity(InsertarConductor)
        }//botonInsertarCoductor

        botonSelectConductor.setOnClickListener {
            val SelectConductor = Intent(applicationContext, ConsultarConductor::class.java).apply {}
            startActivity(SelectConductor)
        }//botonSelectCoductor

           botonInsertVehiculo.setOnClickListener {
            val InsertarVehiculo = Intent(applicationContext, insertarV::class.java).apply {}
            startActivity(InsertarVehiculo)
        }//botonInsertarVehiculo

        botonSelectVehiculo.setOnClickListener {
            val SelectVehiculo = Intent(applicationContext, consultaar_vehiculo::class.java).apply {}
            startActivity(SelectVehiculo)
        }//botonSelectVehiculo

        botonExport.setOnClickListener {
            exportarCSV()
        }//botonSelectVehiculo


    }

    fun exportarCSV(){
        val arregloConductor = Conductor(this).consulta()
        var resultadoConsulta = ArrayList<String>()
        resultadoConsulta = arregloConductor

        val arregloConductor2 = Vehiculo(this).consulta()
        var resultadoConsulta2 = ArrayList<String>()
        resultadoConsulta2 = arregloConductor2

        val arregloConductor3 = Conductor(this).consultaRelaciones()
        var resultadoConsulta3 = ArrayList<String>()
        resultadoConsulta3 = arregloConductor3

        try {
            var textoAGuardar = ""
            var textoAGuardar2 = ""
            var textoAGuardar3 = ""
            //val archivo = OutputStreamWriter(openFileOutput("conductor" + ".txt", MODE_PRIVATE))
            for(i in resultadoConsulta) {
                var aux = i.split("\n")
                textoAGuardar = textoAGuardar+aux[0]+"," + aux[1]+","+aux[2]+","+aux[3]+","+aux[4]+"\n"
            }

            for(i in resultadoConsulta2) {
                var aux = i.split("\n")
                textoAGuardar2 = textoAGuardar2+aux[0]+"," + aux[1]+","+aux[2]+","+aux[3]+","+aux[4]+","+aux[5]+"\n"
            }

            for(i in resultadoConsulta3) {
                var aux = i.split("\n")
                textoAGuardar3 = textoAGuardar3+aux[0]+"\n"
            }

            val tarjetaSD = getExternalFilesDir(null)
            val file = File(tarjetaSD!!.absolutePath, "Conductores.csv")
            val flujoArchivo = OutputStreamWriter(FileOutputStream(file))
            flujoArchivo.write(textoAGuardar)
            flujoArchivo.flush()
            flujoArchivo.close()

            val tarjetaSD2 = getExternalFilesDir(null)
            val file2 = File(tarjetaSD2!!.absolutePath, "Vehiculos.csv")
            val flujoArchivo2 = OutputStreamWriter(FileOutputStream(file2))
            flujoArchivo2.write(textoAGuardar2)
            flujoArchivo2.flush()
            flujoArchivo2.close()

            val tarjetaSD3 = getExternalFilesDir(null)
            val file3 = File(tarjetaSD3!!.absolutePath, "AsingacionConductorVehiculo.csv")
            val flujoArchivo3 = OutputStreamWriter(FileOutputStream(file3))
            flujoArchivo3.write(textoAGuardar3)
            flujoArchivo3.flush()
            flujoArchivo3.close()




            AlertDialog.Builder(this)
                .setTitle("EXITO")
                .setMessage("Se guardaron archivos")
                .setPositiveButton("ACEPTAR"){d,i->d.dismiss()}
                .show()

        }catch (io:Exception){
            Toast.makeText(this, "ERROR :${io.message}", Toast.LENGTH_LONG)
                .show()
        }
        /* archivo.write(textoAGuardar) //hace el guardado de datos  en archivo
         archivo.flush()// forza a guardar  en este momento
         archivo.close() //se cierra para evitar alteraciones
         Toast.makeText(this, "Se guardo con exito", Toast.LENGTH_LONG)
             .show()
         //generartextView(textoTitulo,textocontenido)
     } catch (io: IOException) {
         AlertDialog.Builder(this)
             .setTitle("ATENCION!M ERROR")
             .setMessage(io.message)
             .setPositiveButton("ACEPTAR") { dialog, exception ->
                 dialog.dismiss()
             }
             .show()
     }*/
        /*for(i in exportarArchivo){

            var aux = i.split("\n")
            Toast.makeText(this,"${aux[0]} ${aux[1]} ${aux[2]} ${aux[3]} ${aux[4]}", Toast.LENGTH_LONG).show()
        }//for*/
    }//exportarCSV

}