package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.ContentValues
import android.content.Context
import kotlinx.android.synthetic.main.activity_consultaar_vehiculo.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class Vehiculo(p: Context) {
    var placa = ""
    var marca = ""
    var modelo = ""
    var fecha = ""
    var idconductor = ""
    var pnt = p

    fun insertar():Boolean{
        //ABSTRACCION = no se comunica con el usuario final
        //en la forma de programacion llamada modelo - vista - controlador

        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).writableDatabase
        val dato = ContentValues()
        dato.put("placa",placa)
        dato.put("marca",marca)
        dato.put("modelo",modelo)
        dato.put("yearr",fecha)
        dato.put("idconductor",idconductor)


        val resultado = tablaVehiculo.insert("Vehiculo",null,dato)
        //insert ID mayor 0 no renglon insertado= si se pudo
        //y regresa un -1 Long (entero largo) = no se pudp
        tablaVehiculo.close()
        if(resultado == -1L){
            return false
        }

        return true
    }//insertar----------------------------------------------------------------------------------------------------

    fun consulta(): ArrayList<String>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)
        val cursor = tablaVehiculo.query("Vehiculo",arrayOf("*"),null,null,null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{

                dato = cursor.getString(1)+"\n"+cursor.getString(2)+"\n"+cursor.getString(3)+"\n"+cursor.getString(4)+"\n"+cursor.getString(5)+"\n"+":${cursor.getInt(0)}"
                resultadoConsulta.add(dato)
            }while(cursor.moveToNext())
        }else{
            //no hay resultado de la consulta, es decir cursor esta vacio
            resultadoConsulta.add("No hay vehiculos")
        }
        tablaVehiculo.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------

    fun consultaConductor(vehi: Int): ArrayList<String>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)
        val cursor = tablaVehiculo.query("Vehiculo",arrayOf("*"),"IDVEHICULO=?", arrayOf(vehi.toString()),null,null,null )
        cursor.moveToFirst()
        val cursor2 = tablaConductor.query("Conductor",arrayOf("*"),"IDCONDUCTOR=?", arrayOf(cursor.getString(5)),null,null,null )

        if(cursor2.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{
                dato = cursor2.getString(0)+"\n"+cursor2.getString(1)+"\n"+cursor2.getString(2)+"\n"+cursor2.getString(3)+"\n"+cursor2.getString(4)
                resultadoConsulta.add(dato)
            }while(cursor2.moveToNext())
        }
        tablaVehiculo.close()
        tablaConductor.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------


    fun consulta(idABuscar:String):Vehiculo{
        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val cursor = tablaVehiculo.query("Vehiculo", arrayOf("*"),"IDVEHICULO=?", arrayOf(idABuscar),null,null,null)
        val vehiculo = Vehiculo(MainActivity())
        if(cursor.moveToFirst()){
            vehiculo.placa = cursor.getString(1)
            vehiculo.marca = cursor.getString(2)
            vehiculo.modelo = cursor.getString(3)
            vehiculo.fecha = cursor.getString(4)
            vehiculo.idconductor = cursor.getString(5)
        }//if
        return vehiculo //nombre = ""
    }//consulta-------------------------------------------------------------------------------------

    fun actualizar(idActualizar:String):Boolean{
        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).writableDatabase
        val datos = ContentValues()
        datos.put("placa",placa)
        datos.put("marca",marca)
        datos.put("modelo",modelo)
        datos.put("yearr",fecha)
        datos.put("idconductor",idconductor)
        val resultado = tablaVehiculo.update("Vehiculo",datos,"IDVEHICULO=?", arrayOf(idActualizar))
        if(resultado==0)return false
        return true
    }//actualizar---------------------------------------------------------------------------------------------


    fun obtenerIDs(): ArrayList<Int>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaVehiculos = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultado = ArrayList<Int>()
        //select * from artista (no tiene where)
        val cursor = tablaVehiculos.query("Vehiculo",arrayOf("*"),null,null,null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{
                resultado.add(cursor.getInt(0))
            }while(cursor.moveToNext())
        }
        tablaVehiculos.close()
        return resultado
    }//ObtenerIDs

    fun eliminar(idEliminar:Int):Boolean{
        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).writableDatabase
        val resultado = tablaVehiculo.delete("Vehiculo","IDVEHICULO=?",arrayOf(idEliminar.toString()))
        if(resultado==0)return false
        return true
    }//eliminar-------------------------------------------------------------------------------------------

}
