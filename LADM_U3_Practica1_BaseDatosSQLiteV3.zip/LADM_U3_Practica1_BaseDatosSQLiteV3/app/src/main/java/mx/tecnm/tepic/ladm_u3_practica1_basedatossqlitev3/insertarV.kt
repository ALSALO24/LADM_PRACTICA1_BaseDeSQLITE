package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_insertar_v.*

class insertarV : AppCompatActivity() {
    var idVehiculo= ArrayList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar_v)

        agregar.setOnClickListener {
            val vehiculo = Vehiculo(this)
            vehiculo.placa = CodPlaca.text.toString()
            vehiculo.marca = NombreMarca.text.toString()
            vehiculo.modelo = NombreModelo.text.toString()
            vehiculo.fecha = FechaAño.text.toString()
            vehiculo.idconductor = IdConductor.text.toString()

            val resultado = vehiculo.insertar()
            if(resultado){
                Toast.makeText(this,"SE CAPTURO DATO", Toast.LENGTH_LONG).show()
                CodPlaca.setText("")
                NombreMarca.setText("")
                NombreModelo.setText("")
                FechaAño.setText("")
                IdConductor.setText("")
            }else{
                Toast.makeText(this,"ERROR", Toast.LENGTH_LONG).show()
            }
        }//agregar

        regresar.setOnClickListener {
            finish()
        }//regresar
    }//onCreate
}