package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startTimer()

    }

    fun startTimer(){
        object : CountDownTimer(1000,1000){
            override fun onTick(millisUntilFinished: Long) {
            }

            override fun onFinish() {
                val ventana2 = Intent(applicationContext, MainActivity2::class.java).apply {}
                startActivity(ventana2)
            }
        }.start()
    }//fun
}