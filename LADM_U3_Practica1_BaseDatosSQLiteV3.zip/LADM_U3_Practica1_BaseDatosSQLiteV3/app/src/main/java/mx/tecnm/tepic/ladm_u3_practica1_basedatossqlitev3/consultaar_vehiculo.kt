package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_consulta_vehiculo.*
import kotlinx.android.synthetic.main.activity_consulta_vehiculo.listaVehiculos
import kotlinx.android.synthetic.main.activity_consultaar_vehiculo.*
import kotlinx.android.synthetic.main.activity_consultar_conductor.*
import kotlinx.android.synthetic.main.activity_consultar_conductor.Buscar
import kotlinx.android.synthetic.main.activity_consultar_conductor.Regresar
import kotlinx.android.synthetic.main.activity_consultar_conductor.exportar
import kotlinx.android.synthetic.main.activity_consultar_conductor.opcionJuego
import java.io.IOException
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class consultaar_vehiculo : AppCompatActivity() {
    var idVehiculo= ArrayList<Int>()
    var idCond= ArrayList<Int>()
    var exportarArchivo = ArrayList<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultaar_vehiculo)
        listaCaptura()

        Buscar.setOnClickListener {

            var operacion = opcionJuegov.selectedItemPosition
            when (operacion) {
                0 -> {
                    listaCaptura()
                }
                1 -> {
                   listayearv()
                }

            }//when
        }//Buscar

        Regresar.setOnClickListener {
            finish()
        }//regresar

        exportar.setOnClickListener {

        }//exportar
    }//onCreate

    private fun listaCaptura(){
        val arregloV = Vehiculo(this).consulta()
        exportarArchivo = arregloV
        listaVehiculos.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arregloV)
        idVehiculo.clear()
        idVehiculo = Vehiculo(this).obtenerIDs()
        idCond = Conductor(this).obtenerIDs()
        activarEvento(listaVehiculos)

    }//listaCaptura

    private fun listayearv(){

        val date = Date()
        val v = Vehiculo(this)

        val getYearFormat = SimpleDateFormat("yyyy")
        val currentYear: Int = getYearFormat.format(date).toString().toInt()
        val yearsv = years.text.toString().toInt()
        //val totala = currentYear - yearsv

        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaVehiculo = BaseDatos(v.pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)


            val cursor = tablaVehiculo.query(
                "Vehiculo", arrayOf("*"), "YEARR <= date('now','start of year')-?",
                arrayOf(yearsv.toString()), null, null, null
            )
            if (cursor.moveToFirst()) {
                //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
                var dato = ""
                do {

                    dato =
                        cursor.getString(1) + "\n" + cursor.getString(2) + "\n" + cursor.getString(3) + "\n" + cursor.getString(
                            4
                        ) + "\n" + cursor.getString(5) + "\n" + ":${cursor.getInt(0)}"
                    resultadoConsulta.add(dato)
                } while (cursor.moveToNext())
            } else {
                //no hay resultado de la consulta, es decir cursor esta vacio
                resultadoConsulta.add("No hay vehiculos")
            }

        tablaVehiculo.close()

        listaVehiculos.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,resultadoConsulta)
        encontrarID(resultadoConsulta)
    }//listaCaptura

    private fun activarEvento(listaVehiculo: ListView){
        listaVehiculo.setOnItemClickListener { adapterView, view, indiceSeleccionado, l ->
            val idSeleccionado = idVehiculo[indiceSeleccionado]
            val conductor = Vehiculo(this).consultaConductor(idSeleccionado)

            AlertDialog.Builder(this)
                .setTitle("ATENCION")
                .setMessage("Que desea hacer con el Vehiculo?")
                .setPositiveButton("Ver Conductor"){d,i->
                    AlertDialog.Builder(this)
                        .setTitle("Conductor")
                        .setMessage(conductor.toString())
                        .setNeutralButton("Cerrar"){d,i-> d.cancel()}
                        .show()
                }
                .setNegativeButton("Modificar"){d,i->
                    AlertDialog.Builder(this)
                        .setTitle("ATENCION")
                        .setMessage("Que desea Realizar?")
                        .setPositiveButton("Actualizar"){d,i-> actualizar(idSeleccionado)}
                        .setNegativeButton("Eliminar"){d,i->eliminar(idSeleccionado)}
                        .setNeutralButton("Cancelar"){d,i-> d.cancel()}
                        .show()
                }
                .setNeutralButton("Cancelar"){d,i-> d.cancel()}
                .show()
        }
    }//activarEvento

    private fun actualizar(idSeleccionado: Int){
        val intento = Intent(this, actualizar_vehiculo::class.java)
        intento.putExtra("idActualizar",idSeleccionado.toString())
        startActivity(intento)
        AlertDialog.Builder(this).setMessage("DESEAS ACTUALIZAR LISTA?")
            .setPositiveButton("SI "){d,i-> listaCaptura()}
            .setNegativeButton("NO "){d,i-> d.cancel()}
            .show()
    }//actualizar

    private fun eliminar(idSeleccionado:Int){
        AlertDialog.Builder(this)
            .setTitle("IMPORTANTE")
            .setMessage("Seguro que deseas eliminar ID ${idSeleccionado}")
            .setPositiveButton("Si"){d,i->
                val resultado = Vehiculo(this).eliminar(idSeleccionado)
                if(resultado){
                    Toast.makeText(this,"Se elemino con exito", Toast.LENGTH_LONG).show()
                    listaCaptura()
                }else{
                    Toast.makeText(this,"Error no se logro eliminar", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("No"){d,i->
                d.cancel()
            }
            .show()
    }//eliminar

    private fun encontrarID(arregloVehi: ArrayList<String>) {
        exportarArchivo = arregloVehi
        val id = ArrayList<Int>()
        if (!(arregloVehi[0] == "No hay vehiculos")) {
            for(i in arregloVehi){
                var aux = i.split(":")
                id.add(aux[1].toInt())
            }
            idVehiculo.clear()
            idVehiculo = id
            activarEvento(listaVehiculos)
        }
    }//encontrarID

    private fun exportarCSV(){
        try {
            var textoAGuardar = ""
            val archivo = OutputStreamWriter(openFileOutput("conductor" + ".txt", MODE_PRIVATE))
            Toast.makeText(this, "${archivo}", Toast.LENGTH_LONG).show()
            for(i in exportarArchivo) {
                var aux = i.split("\n")
                textoAGuardar = textoAGuardar+aux[0]+"," + aux[1]+","+aux[2]+","+aux[3]+","+aux[4]+"\n"
            }
            archivo.write(textoAGuardar) //hace el guardado de datos  en archivo
            archivo.flush()// forza a guardar  en este momento
            archivo.close() //se cierra para evitar alteraciones
            Toast.makeText(this, "Se guardo con exito", Toast.LENGTH_LONG)
                .show()
            //generartextView(textoTitulo,textocontenido)
        } catch (io: IOException) {
            AlertDialog.Builder(this)
                .setTitle("ATENCION!M ERROR")
                .setMessage(io.message)
                .setPositiveButton("ACEPTAR") { dialog, exception ->
                    dialog.dismiss()
                }
                .show()
        }
        /*for(i in exportarArchivo){
            var aux = i.split("\n")
            Toast.makeText(this,"${aux[0]} ${aux[1]} ${aux[2]} ${aux[3]} ${aux[4]}", Toast.LENGTH_LONG).show()
        }//for*/
    }//exportarCSV
}