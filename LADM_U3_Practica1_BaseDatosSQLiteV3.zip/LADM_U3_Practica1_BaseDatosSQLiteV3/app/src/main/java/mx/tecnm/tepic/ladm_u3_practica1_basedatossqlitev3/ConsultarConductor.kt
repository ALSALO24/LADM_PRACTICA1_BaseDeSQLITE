package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.iterator
import androidx.core.view.size
import kotlinx.android.synthetic.main.activity_consultar_conductor.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter

class ConsultarConductor : AppCompatActivity() {
    var idConductor= ArrayList<Int>()
    var exportarArchivo = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultar_conductor)
        listaCaptura()

        Buscar.setOnClickListener {

            var operacion = opcionJuego.selectedItemPosition
            when (operacion) {
                0 -> {
                    listaCaptura()
                }
                1 -> {
                    listaCapturaLicenciaVencida()
                }
                2 -> {
                    listaCapturaNoTieneVehiculo()
                }
            }//when
        }//Buscar

        Regresar.setOnClickListener {
            finish()
        }//regresar

        exportar.setOnClickListener {
            exportarCSV()
        }//exportar
    }//onCreate

    private fun listaCaptura(){
        val arregloConductor = Conductor(this).consulta()
        exportarArchivo = arregloConductor
        listaConductores.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arregloConductor)
        idConductor.clear()
        idConductor = Conductor(this).obtenerIDs()
        activarEvento(listaConductores)
    }//listaCaptura

    private fun listaCapturaLicenciaVencida(){
        val arregloConductor = Conductor(this).consultaLicenciaVencida()
        listaConductores.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arregloConductor)
        encontrarID(arregloConductor)
    }

    private fun listaCapturaNoTieneVehiculo(){
        val arregloConductor = Conductor(this).consultaNoTenganVehiculo()
        listaConductores.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arregloConductor)
        encontrarID(arregloConductor)
    }

    private fun activarEvento(listaConductor: ListView){
        listaConductor.setOnItemClickListener { adapterView, view, indiceSeleccionado, l ->
            val idSeleccionado = idConductor[indiceSeleccionado]
            val vehiculo = Conductor(this).consultaVehiculo(idSeleccionado)
            AlertDialog.Builder(this)
                .setTitle("ATENCION")
                .setMessage("Que desea hacer con el Conductor?")
                .setPositiveButton("Ver Vehiculo"){d,i->
                    AlertDialog.Builder(this)
                        .setTitle("Vehiculo")
                        .setMessage(vehiculo.toString())
                        .setNeutralButton("Cerrar"){d,i-> d.cancel()}
                        .show()
                }
                .setNegativeButton("Modificar"){d,i->
                    AlertDialog.Builder(this)
                        .setTitle("ATENCION")
                        .setMessage("Que desea Realizar?")
                        .setPositiveButton("Actualizar"){d,i-> actualizar(idSeleccionado)}
                        .setNegativeButton("Eliminar"){d,i->eliminar(idSeleccionado)}
                        .setNeutralButton("Cancelar"){d,i-> d.cancel()}
                        .show()
                }
                .setNeutralButton("Cancelar"){d,i-> d.cancel()}
                .show()
        }
    }//activarEvento

    private fun actualizar(idSeleccionado: Int){
        val intento = Intent(this, ActualizarConductor::class.java)
        intento.putExtra("idActualizar",idSeleccionado.toString())
        startActivity(intento)
        AlertDialog.Builder(this).setMessage("DESEAS ACTUALIZAR LISTA?")
            .setPositiveButton("SI "){d,i-> listaCaptura()}
            .setNegativeButton("NO "){d,i-> d.cancel()}
            .show()
    }//actualizar

    private fun eliminar(idSeleccionado:Int){
        AlertDialog.Builder(this)
            .setTitle("IMPORTANTE")
            .setMessage("Seguro que deseas eliminar ID ${idSeleccionado}")
            .setPositiveButton("Si"){d,i->
                val resultado = Conductor(this).eliminar(idSeleccionado)
                if(resultado){
                    Toast.makeText(this,"Se elemino con exito", Toast.LENGTH_LONG).show()
                    listaCaptura()
                }else{
                    Toast.makeText(this,"Error no se logro eliminar", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("No"){d,i->
                d.cancel()
            }
            .show()
    }//eliminar

    private fun encontrarID(arregloConductor: ArrayList<String>) {
        exportarArchivo = arregloConductor
        val id = ArrayList<Int>()
        if (!(arregloConductor[0] == "No hay Conductores")) {
            for(i in arregloConductor){
                var aux = i.split(":")
                id.add(aux[1].toInt())
            }
            idConductor.clear()
            idConductor = id
            activarEvento(listaConductores)
        }
    }//encontrarID

    private fun exportarCSV(){
        try {
            var textoAGuardar = ""
            //val archivo = OutputStreamWriter(openFileOutput("conductor" + ".txt", MODE_PRIVATE))
            for(i in exportarArchivo) {
                var aux = i.split("\n")
                textoAGuardar = textoAGuardar+aux[0]+"," + aux[1]+","+aux[2]+","+aux[3]+","+aux[4]+"\n"
            }

            val tarjetaSD = getExternalFilesDir(null)
            val file = File(tarjetaSD!!.absolutePath, "Conductor.csv")
            val flujoArchivo = OutputStreamWriter(FileOutputStream(file))
            flujoArchivo.write(textoAGuardar)
            flujoArchivo.flush()
            flujoArchivo.close()

            AlertDialog.Builder(this)
                .setTitle("EXITO")
                .setMessage("Se guardo archivo")
                .setPositiveButton("ACEPTAR"){d,i->d.dismiss()}
                .show()

        }catch (io:Exception){
            Toast.makeText(this, "ERROR :${io.message}", Toast.LENGTH_LONG)
                .show()
        }
        /* archivo.write(textoAGuardar) //hace el guardado de datos  en archivo
         archivo.flush()// forza a guardar  en este momento
         archivo.close() //se cierra para evitar alteraciones
         Toast.makeText(this, "Se guardo con exito", Toast.LENGTH_LONG)
             .show()
         //generartextView(textoTitulo,textocontenido)
     } catch (io: IOException) {
         AlertDialog.Builder(this)
             .setTitle("ATENCION!M ERROR")
             .setMessage(io.message)
             .setPositiveButton("ACEPTAR") { dialog, exception ->
                 dialog.dismiss()
             }
             .show()
     }*/
        /*for(i in exportarArchivo){

            var aux = i.split("\n")
            Toast.makeText(this,"${aux[0]} ${aux[1]} ${aux[2]} ${aux[3]} ${aux[4]}", Toast.LENGTH_LONG).show()
        }//for*/
    }//exportarCSV
}