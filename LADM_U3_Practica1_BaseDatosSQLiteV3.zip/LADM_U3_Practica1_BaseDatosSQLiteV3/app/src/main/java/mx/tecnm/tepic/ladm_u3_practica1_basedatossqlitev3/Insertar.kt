package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_consultar_conductor.*
import kotlinx.android.synthetic.main.activity_insertar.*

class Insertar : AppCompatActivity() {

    var idConductor= ArrayList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar)

        agregar.setOnClickListener {
            val conductor = Conductor(this)
            conductor.nombre = NombreConductor.text.toString()
            conductor.domicilio = DomicilioConductor.text.toString()
            conductor.NoLicencia = LicenciaConductor.text.toString()
            conductor.vencer = VencimientoLicenciaConductor.text.toString()

            val resultado = conductor.insertar()
            if(resultado){
                Toast.makeText(this,"SE CAPTURO DATO", Toast.LENGTH_LONG).show()
                NombreConductor.setText("")
                DomicilioConductor.setText("")
                LicenciaConductor.setText("")
                VencimientoLicenciaConductor.setText("")
            }else{
                Toast.makeText(this,"ERROR", Toast.LENGTH_LONG).show()
            }
        }//agregar

        regresar.setOnClickListener {
            finish()
        }//regresar
    }//onCreate


}