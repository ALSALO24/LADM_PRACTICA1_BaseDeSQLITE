package mx.tecnm.tepic.ladm_u3_practica1_basedatossqlitev3

import android.content.ContentValues
import android.content.Context
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.*
import kotlin.collections.ArrayList
import kotlin.coroutines.coroutineContext

class Conductor(p:Context) {
    var nombre = ""
    var domicilio = ""
    var NoLicencia = ""
    var vencer = ""
    var pnt = p

    fun insertar():Boolean{
        //ABSTRACCION = no se comunica con el usuario final
        //en la forma de programacion llamada modelo - vista - controlador
        //                                  BASEDAOS MAINACTIVITY ARTISTA

        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).writableDatabase
        val dato = ContentValues()
        dato.put("nombre",nombre)
        dato.put("domicilio",domicilio)
        dato.put("NoLicencia",NoLicencia)
        dato.put("vencer",vencer)

        val resultado = tablaConductor.insert("Conductor",null,dato)
        //insert ID mayor 0 no renglon insertado= si se pudo
        //y regresa un -1 Long (entero largo) = no se pudp
        tablaConductor.close()
        if(resultado == -1L){
            return false
        }

        return true
    }//insertar----------------------------------------------------------------------------------------------------

    fun consulta(): ArrayList<String>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)
        val cursor = tablaConductor.query("Conductor",arrayOf("*"),null,null,null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{

                dato = cursor.getString(1)+"\n"+cursor.getString(2)+"\n"+cursor.getString(3)+"\n"+cursor.getString(4)+"\n"+":${cursor.getInt(0)}"
                resultadoConsulta.add(dato)
            }while(cursor.moveToNext())
        }else{
            //no hay resultado de la consulta, es decir cursor esta vacio
            resultadoConsulta.add("No hay conductores")
        }
        tablaConductor.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------

    fun consultaRelaciones(): ArrayList<String>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val tablaV = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)
        val cursor = tablaConductor.query("Conductor",arrayOf("*"),"IDCONDUCTOR not in(select IDCONDUCTOR from Vehiculo)",null,null,null,null )
        val cursor2 = tablaV.query("Vehiculo",arrayOf("IDCONDUCTOR, IDVEHICULO"),null,null,null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{

                dato = cursor.getString(0)
                resultadoConsulta.add(dato)

            }while(cursor.moveToNext())
        }else{
            //no hay resultado de la consulta, es decir cursor esta vacio
            resultadoConsulta.add("No hay conductores")
        }

        if(cursor2.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{

                dato = cursor2.getString(0) +"\n"+cursor2.getString(1)
                resultadoConsulta.add(dato)

            }while(cursor2.moveToNext())
        }

        tablaConductor.close()
        tablaV.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------

    fun consultaLicenciaVencida(): ArrayList<String>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        val sdf = SimpleDateFormat("yyyy-MM-dd")
        val currentDate = sdf.format(Date())
        //select * from artista (no tiene where)
        val cursor = tablaConductor.query("Conductor",arrayOf("*"),"vencer<?", arrayOf(currentDate.toString()),null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{
                dato = cursor.getString(1)+"\n"+cursor.getString(2)+"\n"+cursor.getString(3)+"\n"+cursor.getString(4)+"\n"+":${cursor.getInt(0)}"
                resultadoConsulta.add(dato)
            }while(cursor.moveToNext())
        }else{
            //no hay resultado de la consulta, es decir cursor esta vacio
            resultadoConsulta.add("No hay Conductores")
        }
        tablaConductor.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------

    fun consultaNoTenganVehiculo(): ArrayList<String>{
        var bandera = false
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)
        val cursor = tablaConductor.query("Conductor",arrayOf("*"),"IDCONDUCTOR not in(select IDCONDUCTOR from Vehiculo)", null,null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{
                dato = cursor.getString(1)+"\n"+cursor.getString(2)+"\n"+cursor.getString(3)+"\n"+cursor.getString(4)+"\n"+":${cursor.getInt(0)}"
                resultadoConsulta.add(dato)
                bandera = true
            }while(cursor.moveToNext())
        }
        if(!bandera){resultadoConsulta.add("No hay Conductores")}
        tablaConductor.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------

    fun obtenerIDs(): ArrayList<Int>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultado = ArrayList<Int>()
        //select * from artista (no tiene where)
        val cursor = tablaConductor.query("Conductor",arrayOf("*"),null,null,null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{
                resultado.add(cursor.getInt(0))
            }while(cursor.moveToNext())
        }
        tablaConductor.close()
        return resultado
    }//ObtenerIDs

    fun consultaVehiculo(trabajador: Int): ArrayList<String>{
        //curso = objeto que obtiene el resultado de un select es una especie de tabla dinamica
        val tablaVehiculo = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val resultadoConsulta = ArrayList<String>()
        //select * from artista (no tiene where)
        val cursor = tablaVehiculo.query("Vehiculo",arrayOf("*"),"IDCONDUCTOR=?", arrayOf(trabajador.toString()),null,null,null )
        if(cursor.moveToFirst()){
            //si moveTOfirst es verdadero, significa que al menos hay 1 resultado
            var dato = ""
            do{
                dato = cursor.getString(0)+"\n"+cursor.getString(1)+"\n"+cursor.getString(2)+"\n"+cursor.getString(3)+"\n"+cursor.getString(4)
                resultadoConsulta.add(dato)
            }while(cursor.moveToNext())
        }
        tablaVehiculo.close()
        return resultadoConsulta
    }//consulta---------------------------------------------------------------------------------------------------------

    fun actualizar(idActualizar:String):Boolean{
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).writableDatabase
        val datos = ContentValues()
        datos.put("nombre",nombre)
        datos.put("domicilio",domicilio)
        datos.put("NoLicencia",NoLicencia)
        datos.put("vencer",vencer)
        val resultado = tablaConductor.update("Conductor",datos,"IDCONDUCTOR=?", arrayOf(idActualizar))
        if(resultado==0)return false
        return true
    }//actualizar---------------------------------------------------------------------------------------------

    fun consulta(idABuscar:String):Conductor{
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).readableDatabase
        val cursor = tablaConductor.query("Conductor", arrayOf("*"),"IDCONDUCTOR=?", arrayOf(idABuscar),null,null,null)
        val conductor = Conductor(MainActivity())
        if(cursor.moveToFirst()){
            conductor.nombre = cursor.getString(1)
            conductor.domicilio = cursor.getString(2)
            conductor.NoLicencia = cursor.getString(3)
            conductor.vencer = cursor.getString(4)
        }//if
        return conductor //nombre = ""
    }//consulta-------------------------------------------------------------------------------------

    fun eliminar(idEliminar:Int):Boolean{
        val tablaConductor = BaseDatos(pnt,"paqueteriaDHL",null,1).writableDatabase
        val resultado = tablaConductor.delete("Conductor","IDCONDUCTOR=?",arrayOf(idEliminar.toString()))
        if(resultado==0)return false
        return true
    }//eliminar-------------------------------------------------------------------------------------------
}